HASSAN TRADING PRO — PRIVATE STAGING SETUP (NOT DEPLOYED)
========================================================

IMPORTANT
---------
This package has NOT been uploaded or deployed to Cloudflare. It does not
change www.tradingpro.live or any existing users/data. Do not attach the Worker
to the production hostname. Use a separate staging hostname/project only.

CONFIGURATION
-------------
Owner email: sikanderwahla@gmail.com
New user demo starting balance: USD 10,000
Mode: Paper Trading only
Owner approval: required before user login

WHAT IS INCLUDED
----------------
- index.html: terminal UI with signup/login gate and owner approve/reject UI
- worker/: Cloudflare Worker API for signup, login, session, owner approval
- worker/schema.sql: D1 tables for users and sessions
- worker/wrangler.toml: Worker config; database_id is intentionally a placeholder

WHAT IS NOT YET COMPLETE
------------------------
- The D1 service currently stores user identities, approval state and sessions.
- Paper balances, positions, drawings and trade history are still stored in
  browser localStorage under a per-user browser namespace. They are not cloud
  synchronized and can be lost if browser data is cleared.
- This is simulated paper trading only, not a regulated broker or real-money
  execution service.
- Real feed behavior for weekly/monthly candles and cross-symbol TP/SL must be
  tested in a browser against the actual market-data provider before release.

STAGING HOSTNAME
----------------
Create a separate Cloudflare Pages project and use a dedicated staging host,
for example staging.tradingpro.live. Do NOT change the existing production
Pages project, production DNS, or production Worker routes.

CLOUDFLARE SETUP (OWNER MUST RUN WHILE LOGGED INTO THEIR CLOUDFLARE ACCOUNT)
----------------------------------------------------------------------------
1. Install Node.js LTS on the computer, then open PowerShell in this folder.
2. Authenticate Wrangler:
     npx wrangler login
3. Create a dedicated staging D1 database:
     npx wrangler d1 create hassan-trading-pro-staging
4. Copy the database_id printed by Wrangler into worker/wrangler.toml, replacing
   REPLACE_WITH_YOUR_D1_DATABASE_ID. Keep database_name unchanged.
5. Apply the schema to the staging database:
     npx wrangler d1 execute hassan-trading-pro-staging --remote --file=worker/schema.sql
6. Set the owner identity and a one-time long random bootstrap secret:
     npx wrangler secret put OWNER_EMAIL
       value: sikanderwahla@gmail.com
     npx wrangler secret put OWNER_BOOTSTRAP_SECRET
       value: generate a unique random secret (do not send it in chat)
   Run these commands from the worker folder.
7. Deploy the API Worker:
     cd worker
     npx wrangler deploy
8. Add a Worker route ONLY for the staging hostname:
     staging.tradingpro.live/api/*
   Bind the Worker to the staging Pages project/hostname so /api/* reaches it.
   The Pages static site must use the same staging hostname so HttpOnly session
   cookies remain same-origin.
9. Create a separate Cloudflare Pages project for staging and deploy the site
   root (the folder containing index.html and _headers). Keep production project
   and custom domain untouched.
10. Open the staging URL. Use First-time owner setup once, with the configured
    owner email, your chosen strong password (12+ characters), and the secret.
    After owner setup, delete/disable the bootstrap secret and remove the
    first-time setup panel before any public release.

TEST CHECKLIST
--------------
- Owner bootstrap succeeds once; second bootstrap attempt is rejected.
- Owner login succeeds; normal users cannot access owner endpoints.
- New signup is pending and cannot log in before approval.
- Owner can approve and reject pending users.
- Rejected user cannot log in; approved user can log in.
- Two users in separate browser sessions get separate paper UI namespaces.
- BUY and SELL trades: TP and SL hit for chart symbol and non-chart symbols.
- H2, H6, W and M show correct candle intervals, timestamps and timer.
- Test after reload and with market feed disconnected/reconnected.

DO NOT publish this build to tradingpro.live until all tests pass and the owner
explicitly approves production deployment.
