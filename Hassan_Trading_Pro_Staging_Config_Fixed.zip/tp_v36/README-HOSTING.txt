HASSAN TRADING PRO — STATIC SITE DEPLOYMENT

Upload the CONTENTS of this folder to a static hosting provider's site root.
For Cloudflare Pages Direct Upload, upload this folder (or its ZIP) as the site assets.
Then add tradingpro.live as a custom domain in the Pages project and follow the DNS records Cloudflare displays.

This package contains the website only. It does not include the optional local MT5 bridge.
Do not upload bridge scripts or bridge_token.txt to public hosting.

The website's paper-trading state is stored in each browser's local storage. It is not a shared cloud account/database.
