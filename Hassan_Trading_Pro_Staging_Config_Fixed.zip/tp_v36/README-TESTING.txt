# Hassan Trading Pro — corrected private test package

**Not published.** This package is a source build for local/staging verification only.
It does not modify the live `tradingpro.live` deployment.

## Included changes
- Paper TP/SL checks continue to run for open positions on other symbols by polling those symbols in REST fallback mode.
- SignalR subscriptions include symbols with open paper positions.
- Timeframe history loading validates candle spacing against the selected timeframe. It tries provider aliases for weekly/monthly intervals and refuses to silently display 1-minute candles as a higher timeframe.
- Signup/login/owner-approval gate UI and a Cloudflare Worker API are included.
- Paper-only UI hides the Local MT5 real-order mode button.
- Each browser profile uses a separate localStorage namespace after login.

## Important limitations before this can be called production-ready
1. The Worker must be deployed and attached to `tradingpro.live/api/*`; create a Cloudflare D1 database and apply `worker/schema.sql`.
2. Configure Worker variables/secrets before first owner setup:
   - `OWNER_EMAIL=sikanderwahla@gmail.com`
   - secret `OWNER_BOOTSTRAP_SECRET` (use a long random secret; never share it publicly)
   - deploy `worker/` with the supplied `wrangler.toml` after replacing the D1 database ID.
3. First-time owner setup is available on the login page. It requires the one-time bootstrap secret configured in Cloudflare. Use a strong owner password (12+ chars). The owner email is restricted by the Worker to the configured email.
4. User credentials and approval status are stored in D1. Trading terminal state (drawings, paper balance/history and preferences) is currently isolated by browser-local user namespace; cross-device/cloud restore is **not** included yet. Do not describe this as a fully synchronized broker account.
5. The market data API's actual weekly/monthly interval support must be verified against the live feed. If no matching interval is returned, the new loader shows a feed error rather than silently rendering the wrong timeframe.
6. Paper Trading is simulated. It does not execute real broker orders. TP/SL are evaluated when the market feed provides a fresh quote; when a market is closed or the feed is unavailable, a trigger cannot be observed until fresh data resumes.

## Local test
Open `index.html` through a local static server (not `file://`) after configuring a staging API route. Test:
- signup → pending status → owner approval → login
- two different user accounts get separate local paper balance/history in the same browser
- BUY and SELL positions with TP/SL on current and non-current symbols
- H2, H6, W, and M candle spacing and timestamps

## Cloudflare routing
The supplied Worker is a standalone Worker. Bind it to the route `tradingpro.live/api/*` (or your staging hostname's `/api/*`) while Pages continues serving the static files. Do not change production DNS/routes until staging tests pass and owner explicitly approves.
